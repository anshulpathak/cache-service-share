#!/bin/bash
# Remove cache optimization service

HOME_DIR="$HOME"

# Unload services
launchctl unload "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.cacheservice.plist" 2>/dev/null
launchctl unload "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.windowtracker.plist" 2>/dev/null
launchctl unload "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.triggerwatch.plist" 2>/dev/null

# Remove files
rm -f "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.cacheservice.plist"
rm -f "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.windowtracker.plist"
rm -f "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.triggerwatch.plist"
rm -f "$HOME_DIR/.local/share/.cacheserviced.py"
rm -f "$HOME_DIR/.local/share/.triggerwatch.py"
rm -f "$HOME_DIR/.local/.metadata_sync.json"
rm -f "$HOME_DIR/.local/share/.cache_index.db"
rm -rf "$HOME_DIR/.local/share/.cache_reports"

echo "Services removed."
