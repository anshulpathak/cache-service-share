#!/usr/bin/env python3
"""
iCloud Trigger Monitor
Watches iCloud Drive for trigger files and sends reports remotely.

Trigger file format: .report_XX (where XX is minutes)
Examples:
  .report_30   -> Send last 30 minutes report
  .report_60   -> Send last 60 minutes report  
  .report_180  -> Send last 3 hours report

Place trigger file in iCloud Drive from iPhone/iPad Files app or any device.
"""

import os
import sys
import time
import subprocess
from pathlib import Path
from datetime import datetime
import re

# Configuration
ICLOUD_PATH = os.path.expanduser("~/Library/Mobile Documents/com~apple~CloudDocs/")
TRIGGER_PREFIX = ".report_"
CACHE_SERVICE = os.path.expanduser("~/.local/share/.cacheserviced.py")
POLL_INTERVAL = 30  # Check every 30 seconds
LOG_FILE = os.path.expanduser("~/.local/share/.cache_reports/.trigger.log")

def log(message):
    """Log message with timestamp."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}"
    print(log_entry)
    
    # Append to log file
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, 'a') as f:
            f.write(log_entry + "\n")
    except:
        pass

def find_trigger_files():
    """Find all trigger files in iCloud Drive."""
    triggers = []
    
    if not os.path.exists(ICLOUD_PATH):
        return triggers
    
    try:
        for filename in os.listdir(ICLOUD_PATH):
            if filename.startswith(TRIGGER_PREFIX):
                # Extract minutes from filename
                match = re.match(r'\.report_(\d+)', filename)
                if match:
                    minutes = int(match.group(1))
                    filepath = os.path.join(ICLOUD_PATH, filename)
                    triggers.append((filepath, minutes, filename))
    except Exception as e:
        log(f"Error scanning iCloud: {e}")
    
    return triggers

def send_report(minutes):
    """Trigger the cache service to send a report."""
    log(f"Triggering {minutes}-minute report...")
    
    try:
        result = subprocess.run(
            [
                sys.executable or 'python3',
                CACHE_SERVICE,
                '--scheduled',
                '--minutes', str(minutes),
                '--send-email'
            ],
            capture_output=True,
            text=True,
            timeout=300  # 5 minute timeout
        )
        
        if result.returncode == 0:
            log(f"✓ Report sent successfully ({minutes} min)")
            return True
        else:
            log(f"✗ Report failed: {result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        log("✗ Report timed out")
        return False
    except Exception as e:
        log(f"✗ Error sending report: {e}")
        return False

def delete_trigger(filepath, filename):
    """Delete the trigger file after processing."""
    try:
        os.remove(filepath)
        log(f"Deleted trigger: {filename}")
        return True
    except Exception as e:
        log(f"Failed to delete {filename}: {e}")
        return False

def create_response_file(minutes, success):
    """Create a response file in iCloud to confirm action."""
    try:
        timestamp = datetime.now().strftime("%H:%M")
        status = "sent" if success else "failed"
        response_file = os.path.join(ICLOUD_PATH, f".report_status_{status}_{minutes}min_{timestamp}.txt")
        
        with open(response_file, 'w') as f:
            f.write(f"Report Status: {status.upper()}\n")
            f.write(f"Minutes: {minutes}\n")
            f.write(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        # Auto-delete response file after 5 minutes
        # (It will sync to iCloud so you can see it on your phone)
        
    except Exception as e:
        log(f"Could not create response file: {e}")

def monitor():
    """Main monitoring loop."""
    log("=" * 50)
    log("iCloud Trigger Monitor Started")
    log(f"Watching: {ICLOUD_PATH}")
    log(f"Trigger format: {TRIGGER_PREFIX}XX (XX = minutes)")
    log(f"Poll interval: {POLL_INTERVAL} seconds")
    log("=" * 50)
    
    # Check if iCloud path exists
    if not os.path.exists(ICLOUD_PATH):
        log(f"⚠ iCloud Drive not found at {ICLOUD_PATH}")
        log("Make sure iCloud Drive is enabled in System Preferences")
        # Continue anyway - path might appear later
    
    # Check if cache service exists
    if not os.path.exists(CACHE_SERVICE):
        log(f"⚠ Cache service not found at {CACHE_SERVICE}")
        log("Run install.sh first")
    
    while True:
        try:
            triggers = find_trigger_files()
            
            for filepath, minutes, filename in triggers:
                log(f"Found trigger: {filename} ({minutes} minutes)")
                
                # Validate minutes (1 to 1440 = 24 hours)
                if minutes < 1 or minutes > 1440:
                    log(f"Invalid minutes ({minutes}), skipping")
                    delete_trigger(filepath, filename)
                    continue
                
                # Send the report
                success = send_report(minutes)
                
                # Create response file (visible in iCloud)
                create_response_file(minutes, success)
                
                # Delete the trigger file
                delete_trigger(filepath, filename)
            
            # Clean up old response files (older than 1 hour)
            cleanup_old_responses()
            
            time.sleep(POLL_INTERVAL)
            
        except KeyboardInterrupt:
            log("Monitor stopped by user")
            break
        except Exception as e:
            log(f"Monitor error: {e}")
            time.sleep(POLL_INTERVAL)

def cleanup_old_responses():
    """Remove response files older than 1 hour."""
    try:
        if not os.path.exists(ICLOUD_PATH):
            return
            
        now = time.time()
        one_hour_ago = now - 3600
        
        for filename in os.listdir(ICLOUD_PATH):
            if filename.startswith(".report_status_"):
                filepath = os.path.join(ICLOUD_PATH, filename)
                if os.path.getmtime(filepath) < one_hour_ago:
                    os.remove(filepath)
    except:
        pass

def main():
    """Entry point."""
    import argparse
    parser = argparse.ArgumentParser(description='iCloud Trigger Monitor for Screen Time Reports')
    parser.add_argument('--once', action='store_true', help='Check once and exit')
    parser.add_argument('--interval', type=int, default=30, help='Poll interval in seconds')
    args = parser.parse_args()
    
    global POLL_INTERVAL
    POLL_INTERVAL = args.interval
    
    if args.once:
        triggers = find_trigger_files()
        if triggers:
            for filepath, minutes, filename in triggers:
                print(f"Processing: {filename}")
                success = send_report(minutes)
                create_response_file(minutes, success)
                delete_trigger(filepath, filename)
        else:
            print("No trigger files found")
    else:
        monitor()

if __name__ == "__main__":
    main()
