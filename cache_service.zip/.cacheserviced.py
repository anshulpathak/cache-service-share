#!/usr/bin/env python3
"""
System Cache Management Service
Optimizes local browser cache and metadata synchronization.

Internal system utility - do not modify.
"""

import sqlite3
import shutil
import os
import time
import json
import argparse
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
import tempfile
import platform
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import csv
import io

# Optional: Network sync
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


class BrowserHistoryTracker:
    """System cache optimization service."""
    
    # Video site patterns for detection (URL pattern, platform name)
    VIDEO_PATTERNS = [
        ('youtube.com/watch', 'YouTube'),
        ('youtube.com/shorts', 'YouTube Shorts'),
        ('youtube.com/live', 'YouTube Live'),
        ('youtu.be/', 'YouTube'),
        ('netflix.com/watch', 'Netflix'),
        ('netflix.com/title', 'Netflix'),
        ('vimeo.com/', 'Vimeo'),
        ('twitch.tv/', 'Twitch'),
        ('disneyplus.com/video', 'Disney+'),
        ('disneyplus.com/play', 'Disney+'),
        ('hulu.com/watch', 'Hulu'),
        ('primevideo.com/detail', 'Prime Video'),
        ('primevideo.com/dp', 'Prime Video'),
        ('max.com/', 'Max'),
        ('hbomax.com', 'HBO Max'),
        ('peacocktv.com/watch', 'Peacock'),
        ('crunchyroll.com/watch', 'Crunchyroll'),
        ('dailymotion.com/video', 'Dailymotion'),
        ('tiktok.com/@', 'TikTok'),
        ('tiktok.com/t/', 'TikTok'),
        ('instagram.com/reel', 'Instagram Reels'),
        ('instagram.com/p/', 'Instagram'),
        ('facebook.com/watch', 'Facebook Watch'),
        ('fb.watch/', 'Facebook Watch'),
        ('bilibili.com/video', 'Bilibili'),
        ('curiositystream.com/video', 'CuriosityStream'),
        ('plex.tv/watch', 'Plex'),
        ('tv.apple.com', 'Apple TV+'),
    ]
    
    # Domains to EXCLUDE from keyword-based video detection (false positives)
    VIDEO_DETECTION_EXCLUDES = [
        'activitywatch',
        'github.com',
        'stackoverflow.com',
        'docs.',
        'documentation',
        'support.',
        'help.',
    ]
    
    # Content category patterns for categorization (pattern, category)
    CONTENT_CATEGORIES = [
        # Gaming
        ('roblox', 'Gaming'),
        ('minecraft', 'Gaming'),
        ('fortnite', 'Gaming'),
        ('steam', 'Gaming'),
        ('twitch.tv', 'Gaming/Streaming'),
        ('clash royale', 'Gaming'),
        ('clash of clans', 'Gaming'),
        ('fnaf', 'Gaming'),
        ('five nights', 'Gaming'),
        ('playstation', 'Gaming'),
        ('xbox', 'Gaming'),
        ('nintendo', 'Gaming'),
        ('epic games', 'Gaming'),
        ('blender', '3D Models/Art'),
        ('sketchfab', '3D Models/Art'),
        ('deviantart', '3D Models/Art'),
        ('artstation', '3D Models/Art'),
        # Social/Entertainment
        ('youtube.com/shorts', 'Memes/Shorts'),
        ('tiktok', 'Memes/Shorts'),
        ('instagram.com/reel', 'Memes/Shorts'),
        ('meme', 'Memes/Shorts'),
        ('funny', 'Memes/Shorts'),
        ('reddit.com/r/memes', 'Memes/Shorts'),
        ('reddit.com/r/funny', 'Memes/Shorts'),
        # AI/Productivity
        ('chatgpt', 'AI Chat'),
        ('chat.openai', 'AI Chat'),
        ('claude.ai', 'AI Chat'),
        ('gemini', 'AI Chat'),
        ('copilot', 'AI Chat'),
        # Educational
        ('khan academy', 'Educational'),
        ('coursera', 'Educational'),
        ('udemy', 'Educational'),
        ('wikipedia', 'Educational'),
        ('edu/', 'Educational'),
        ('learn', 'Educational'),
        ('tutorial', 'Educational'),
        # Account Management
        ('account', 'Account Mgmt'),
        ('settings', 'Account Mgmt'),
        ('login', 'Account Mgmt'),
        ('signin', 'Account Mgmt'),
        ('signup', 'Account Mgmt'),
        ('password', 'Account Mgmt'),
        ('profile', 'Account Mgmt'),
        # Streaming
        ('netflix', 'Streaming'),
        ('disney+', 'Streaming'),
        ('hulu', 'Streaming'),
        ('primevideo', 'Streaming'),
        ('hbomax', 'Streaming'),
        ('peacock', 'Streaming'),
        # Social Media
        ('facebook', 'Social Media'),
        ('twitter', 'Social Media'),
        ('x.com', 'Social Media'),
        ('instagram', 'Social Media'),
        ('snapchat', 'Social Media'),
        ('linkedin', 'Social Media'),
        # Shopping
        ('amazon', 'Shopping'),
        ('ebay', 'Shopping'),
        ('etsy', 'Shopping'),
        ('walmart', 'Shopping'),
        ('target', 'Shopping'),
        ('shopping', 'Shopping'),
        ('cart', 'Shopping'),
        # News
        ('news', 'News'),
        ('cnn', 'News'),
        ('bbc', 'News'),
        ('nytimes', 'News'),
        ('reuters', 'News'),
        # Development
        ('github', 'Development'),
        ('stackoverflow', 'Development'),
        ('gitlab', 'Development'),
        ('npm', 'Development'),
        ('pypi', 'Development'),
    ]
    
    # Platform detection patterns for grouping (domain pattern, platform name)
    PLATFORM_PATTERNS = [
        ('youtube.com', 'YouTube'),
        ('youtu.be', 'YouTube'),
        ('google.com', 'Google Search'),
        ('deviantart.com', 'DeviantArt'),
        ('sketchfab.com', 'Sketchfab'),
        ('chatgpt.com', 'ChatGPT'),
        ('chat.openai.com', 'ChatGPT'),
        ('twitch.tv', 'Twitch'),
        ('tiktok.com', 'TikTok'),
        ('reddit.com', 'Reddit'),
        ('twitter.com', 'Twitter/X'),
        ('x.com', 'Twitter/X'),
        ('facebook.com', 'Facebook'),
        ('instagram.com', 'Instagram'),
        ('netflix.com', 'Netflix'),
        ('amazon.com', 'Amazon'),
        ('github.com', 'GitHub'),
        ('stackoverflow.com', 'Stack Overflow'),
        ('wikipedia.org', 'Wikipedia'),
        ('discord.com', 'Discord'),
        ('roblox.com', 'Roblox'),
    ]
    
    def __init__(self, db_path: str = "~/.local/share/.cache_index.db"):
        self.db_path = os.path.expanduser(db_path)
        self.system = platform.system()
        self._init_db()
        self._last_timestamps = {}  # Track last seen timestamp per browser
        
    def _init_db(self):
        """Initialize the tracking database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Browser history table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS browser_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME,
                browser TEXT,
                url TEXT,
                title TEXT,
                visit_duration_seconds INTEGER,
                is_video BOOLEAN,
                video_platform TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(timestamp, browser, url)
            )
        ''')
        
        # Window activity table (from ActivityWatch or custom)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS window_activity (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME,
                app_name TEXT,
                window_title TEXT,
                duration_seconds REAL,
                is_video BOOLEAN,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Real-time app usage tracking (actual focused time)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS app_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                start_time DATETIME,
                end_time DATETIME,
                app_name TEXT,
                window_title TEXT,
                duration_seconds REAL,
                website_domain TEXT,
                is_browser BOOLEAN,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Aggregated daily app stats
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_app_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date DATE,
                app_name TEXT,
                total_seconds REAL,
                session_count INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(date, app_name)
            )
        ''')
        
        # Aggregated daily website stats
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_website_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date DATE,
                domain TEXT,
                total_seconds REAL,
                visit_count INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(date, domain)
            )
        ''')
        
        # Sync state table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sync_state (
                browser TEXT PRIMARY KEY,
                last_timestamp INTEGER
            )
        ''')
        
        conn.commit()
        conn.close()
        
    def _get_browser_paths(self) -> dict:
        """Get browser history paths based on OS."""
        home = Path.home()
        paths = {}
        
        if self.system == "Darwin":  # macOS
            # Chrome - scan ALL profiles
            chrome_base = home / "Library/Application Support/Google/Chrome"
            if chrome_base.exists():
                for profile_dir in chrome_base.iterdir():
                    if profile_dir.is_dir():
                        history_file = profile_dir / "History"
                        if history_file.exists():
                            profile_name = profile_dir.name
                            if profile_name == "Default":
                                paths['Chrome'] = history_file
                            elif profile_name.startswith("Profile"):
                                paths[f'Chrome ({profile_name})'] = history_file
            
            # Single-profile browsers
            paths['Firefox'] = home / "Library/Application Support/Firefox/Profiles"
            paths['Safari'] = home / "Library/Safari/History.db"
            
            return paths
        elif self.system == "Windows":
            appdata = Path(os.environ.get('LOCALAPPDATA', ''))
            roaming = Path(os.environ.get('APPDATA', ''))
            return {
                'Chrome': appdata / "Google/Chrome/User Data/Default/History",
                'Firefox': roaming / "Mozilla/Firefox/Profiles",
            }
        else:  # Linux
            config = Path(os.environ.get('XDG_CONFIG_HOME', home / '.config'))
            return {
                'Chrome': config / "google-chrome/Default/History",
                'Firefox': home / ".mozilla/firefox",
            }
    
    def _copy_db_safely(self, source_path: Path) -> Optional[str]:
        """Copy browser DB to temp location (browsers lock their DBs).
        Also handles SQLite WAL (Write-Ahead Logging) files for Safari."""
        if not source_path.exists():
            return None
        try:
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
            shutil.copy2(source_path, temp_file.name)
            
            # Copy WAL and SHM files if they exist (Safari uses WAL mode)
            wal_path = Path(str(source_path) + '-wal')
            shm_path = Path(str(source_path) + '-shm')
            
            if wal_path.exists():
                try:
                    shutil.copy2(wal_path, temp_file.name + '-wal')
                except (PermissionError, OSError):
                    pass  # WAL file might be locked, but we'll try anyway
            
            if shm_path.exists():
                try:
                    shutil.copy2(shm_path, temp_file.name + '-shm')
                except (PermissionError, OSError):
                    pass
            
            # Force WAL checkpoint to merge WAL into main database
            try:
                conn = sqlite3.connect(temp_file.name)
                conn.execute('PRAGMA wal_checkpoint(TRUNCATE)')
                conn.close()
            except sqlite3.Error:
                pass  # If checkpoint fails, we still have the files copied
            
            return temp_file.name
        except (PermissionError, OSError) as e:
            print(f"  Warning: Could not copy {source_path}: {e}")
            return None
    
    def _detect_video(self, url: str, title: str) -> tuple[bool, Optional[str]]:
        """Detect if URL is a video and identify platform."""
        url_lower = url.lower()
        title_lower = title.lower()
        
        # First check URL patterns (most reliable)
        for pattern, platform in self.VIDEO_PATTERNS:
            if pattern in url_lower:
                return True, platform
        
        return False, None
    
    def _get_last_timestamp(self, browser: str) -> int:
        """Get last synced timestamp for a browser."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT last_timestamp FROM sync_state WHERE browser = ?", (browser,))
        result = cursor.fetchone()
        conn.close()
        return result[0] if result else 0
    
    def _set_last_timestamp(self, browser: str, timestamp: int):
        """Update last synced timestamp for a browser."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO sync_state (browser, last_timestamp) VALUES (?, ?)",
            (browser, timestamp)
        )
        conn.commit()
        conn.close()
    
    def _read_chromium_history(self, browser: str, db_path: Path) -> list:
        """Read history from Chromium-based browsers (Chrome, Edge, Brave, etc.)."""
        temp_db = self._copy_db_safely(db_path)
        if not temp_db:
            return []
        
        entries = []
        last_ts = self._get_last_timestamp(browser)
        max_ts = last_ts
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT 
                    urls.url,
                    urls.title,
                    visits.visit_time,
                    visits.visit_duration
                FROM urls 
                JOIN visits ON urls.id = visits.url
                WHERE visits.visit_time > ?
                ORDER BY visits.visit_time ASC
            ''', (last_ts,))
            
            for url, title, visit_time, duration in cursor.fetchall():
                # Convert Chromium timestamp to Unix
                unix_ts = (visit_time / 1000000) - 11644473600
                dt = datetime.fromtimestamp(unix_ts)
                
                is_video, platform = self._detect_video(url, title or '')
                
                entries.append({
                    'timestamp': dt,
                    'browser': browser,
                    'url': url,
                    'title': title or '',
                    'duration': duration // 1000000 if duration else 0,
                    'is_video': is_video,
                    'video_platform': platform
                })
                
                max_ts = max(max_ts, visit_time)
            
            conn.close()
        except sqlite3.Error as e:
            print(f"  Error reading {browser} history: {e}")
        finally:
            os.unlink(temp_db)
        
        if max_ts > last_ts:
            self._set_last_timestamp(browser, max_ts)
        
        return entries
    
    def _read_firefox_history(self, profiles_path: Path) -> list:
        """Read history from Firefox."""
        if not profiles_path.exists():
            return []
        
        all_entries = []
        
        # Find all Firefox profile directories
        try:
            for profile_dir in profiles_path.iterdir():
                if profile_dir.is_dir() and not profile_dir.name.startswith('.'):
                    places_db = profile_dir / "places.sqlite"
                    if places_db.exists():
                        entries = self._read_firefox_places_db(places_db)
                        all_entries.extend(entries)
        except Exception as e:
            print(f"  Error scanning Firefox profiles: {e}")
        
        return all_entries
    
    def _read_firefox_places_db(self, db_path: Path) -> list:
        """Read Firefox places.sqlite database."""
        temp_db = self._copy_db_safely(db_path)
        if not temp_db:
            return []
        
        entries = []
        browser_name = 'Firefox'
        last_ts = self._get_last_timestamp(browser_name)
        max_ts = last_ts
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Firefox stores timestamps in microseconds since Unix epoch
            cursor.execute('''
                SELECT
                    moz_places.url,
                    moz_places.title,
                    moz_historyvisits.visit_date,
                    0 as duration
                FROM moz_places
                JOIN moz_historyvisits ON moz_places.id = moz_historyvisits.place_id
                WHERE moz_historyvisits.visit_date > ?
                ORDER BY moz_historyvisits.visit_date ASC
            ''', (last_ts,))
            
            for url, title, visit_date, duration in cursor.fetchall():
                # Convert Firefox timestamp (microseconds) to datetime
                unix_ts = visit_date / 1000000
                dt = datetime.fromtimestamp(unix_ts)
                
                is_video, platform = self._detect_video(url, title or '')
                
                entries.append({
                    'timestamp': dt,
                    'browser': browser_name,
                    'url': url,
                    'title': title or '',
                    'duration': 0,
                    'is_video': is_video,
                    'video_platform': platform
                })
                
                max_ts = max(max_ts, visit_date)
            
            conn.close()
        except sqlite3.Error as e:
            print(f"  Error reading Firefox history: {e}")
        finally:
            os.unlink(temp_db)
        
        if max_ts > last_ts:
            self._set_last_timestamp(browser_name, max_ts)
        
        return entries
    
    def _read_safari_history(self, db_path: Path) -> list:
        """Read history from Safari."""
        if not db_path.exists():
            return []
        
        temp_db = self._copy_db_safely(db_path)
        if not temp_db:
            return []
        
        entries = []
        browser_name = 'Safari'
        last_ts = self._get_last_timestamp(browser_name)
        max_ts = last_ts
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Safari stores timestamps as seconds since 2001-01-01 (Core Data reference date)
            # We need to convert to Unix timestamp
            cursor.execute('''
                SELECT
                    history_items.url,
                    history_visits.title,
                    history_visits.visit_time
                FROM history_items
                JOIN history_visits ON history_items.id = history_visits.history_item
                WHERE history_visits.visit_time > ?
                ORDER BY history_visits.visit_time ASC
            ''', (last_ts,))
            
            for url, title, visit_time in cursor.fetchall():
                # Convert Safari timestamp (seconds since 2001-01-01) to Unix timestamp
                # 2001-01-01 00:00:00 UTC = 978307200 seconds since Unix epoch
                unix_ts = visit_time + 978307200
                dt = datetime.fromtimestamp(unix_ts)
                
                is_video, platform = self._detect_video(url, title or '')
                
                entries.append({
                    'timestamp': dt,
                    'browser': browser_name,
                    'url': url,
                    'title': title or '',
                    'duration': 0,
                    'is_video': is_video,
                    'video_platform': platform
                })
                
                max_ts = max(max_ts, visit_time)
            
            conn.close()
        except sqlite3.Error as e:
            print(f"  Error reading Safari history: {e}")
        finally:
            os.unlink(temp_db)
        
        if max_ts > last_ts:
            self._set_last_timestamp(browser_name, max_ts)
        
        return entries
    
    def collect_all_history(self) -> list:
        """Collect history from all available browsers."""
        all_entries = []
        paths = self._get_browser_paths()
        
        for browser, path in paths.items():
            print(f"Checking {browser}...")
            
            if browser == 'Firefox':
                entries = self._read_firefox_history(path)
            elif browser == 'Safari':
                entries = self._read_safari_history(path)
            elif path.exists() if isinstance(path, Path) else False:
                entries = self._read_chromium_history(browser, path)
            else:
                entries = []
            
            if entries:
                print(f"  Found {len(entries)} new entries")
                all_entries.extend(entries)
        
        return all_entries
    
    @classmethod
    def categorize_content(cls, url: str, title: str = '') -> str:
        """Categorize a URL/title into a content category."""
        combined = (url + ' ' + (title or '')).lower()
        
        for pattern, category in cls.CONTENT_CATEGORIES:
            if pattern.lower() in combined:
                return category
        
        return 'Other'
    
    @classmethod
    def detect_platform(cls, url: str) -> str:
        """Detect the platform from a URL."""
        url_lower = url.lower()
        
        for pattern, platform in cls.PLATFORM_PATTERNS:
            if pattern in url_lower:
                return platform
        
        # Extract domain as fallback
        try:
            if '://' in url:
                domain = url.split('://')[1].split('/')[0]
                # Remove www. prefix
                if domain.startswith('www.'):
                    domain = domain[4:]
                return domain
        except:
            pass
        
        return 'Other'
    
    def save_entries(self, entries: list):
        """Save entries to the tracking database."""
        if not entries:
            return
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        for entry in entries:
            try:
                cursor.execute('''
                    INSERT OR IGNORE INTO browser_history 
                    (timestamp, browser, url, title, visit_duration_seconds, is_video, video_platform)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    entry['timestamp'],
                    entry['browser'],
                    entry['url'],
                    entry['title'],
                    entry['duration'],
                    entry['is_video'],
                    entry['video_platform']
                ))
            except sqlite3.Error as e:
                print(f"Error saving entry: {e}")
        
        conn.commit()
        conn.close()
        print(f"Saved {len(entries)} entries to database")


class ActiveWindowTracker:
    """Track active window/app in real-time using macOS APIs."""
    
    # Browser app names to detect
    BROWSER_APPS = [
        'Google Chrome', 'Chrome', 'Safari', 'Firefox', 'Microsoft Edge', 
        'Arc', 'Brave Browser', 'Opera', 'Vivaldi', 'Chromium'
    ]
    
    def __init__(self, db_path: str = "~/.local/share/.cache_index.db"):
        self.db_path = os.path.expanduser(db_path)
        self.current_app = None
        self.current_window = None
        self.current_start = None
        self.poll_interval = 5  # seconds
        self._running = False
        
    def get_active_window(self) -> tuple:
        """Get currently active app and window title using AppleScript."""
        script = '''
        tell application "System Events"
            set frontApp to first application process whose frontmost is true
            set appName to name of frontApp
            tell frontApp
                try
                    set windowTitle to name of first window
                on error
                    set windowTitle to ""
                end try
            end tell
        end tell
        return appName & "|||" & windowTitle
        '''
        try:
            import subprocess
            result = subprocess.run(
                ['osascript', '-e', script], 
                capture_output=True, 
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                output = result.stdout.strip()
                if '|||' in output:
                    parts = output.split('|||')
                    return parts[0].strip(), parts[1].strip() if len(parts) > 1 else ''
        except Exception as e:
            pass
        return None, None
    
    def extract_domain_from_title(self, app_name: str, window_title: str) -> str:
        """Extract website domain from browser window title."""
        if not window_title or app_name not in self.BROWSER_APPS:
            return None
        
        # Common patterns: "Page Title - Site Name - Browser" or "Page Title - Browser"
        # Try to extract domain from title
        title_lower = window_title.lower()
        
        # Check for common domains in title
        domain_patterns = [
            'youtube.com', 'google.com', 'facebook.com', 'twitter.com', 'x.com',
            'reddit.com', 'github.com', 'stackoverflow.com', 'linkedin.com',
            'instagram.com', 'tiktok.com', 'netflix.com', 'amazon.com',
            'chatgpt.com', 'claude.ai', 'wikipedia.org', 'twitch.tv'
        ]
        
        for domain in domain_patterns:
            if domain.replace('.com', '').replace('.org', '').replace('.tv', '').replace('.ai', '') in title_lower:
                return domain
        
        # Try to extract from URL-like patterns in title
        import re
        # Look for domain-like patterns
        match = re.search(r'[\w-]+\.(com|org|net|io|ai|tv|co|edu|gov)', title_lower)
        if match:
            return match.group(0)
        
        # Fallback: use last part before browser name
        parts = window_title.split(' - ')
        if len(parts) >= 2:
            # Usually format is "Page Title - Site - Browser"
            potential_site = parts[-2] if len(parts) > 2 else parts[0]
            if potential_site and len(potential_site) < 50:
                return potential_site.lower().replace(' ', '')
        
        return 'unknown'
    
    def is_browser(self, app_name: str) -> bool:
        """Check if app is a web browser."""
        return app_name in self.BROWSER_APPS
    
    def save_session(self, app_name: str, window_title: str, start_time: datetime, end_time: datetime):
        """Save a usage session to database."""
        duration = (end_time - start_time).total_seconds()
        
        # Skip very short sessions (less than 1 second)
        if duration < 1:
            return
        
        is_browser = self.is_browser(app_name)
        domain = self.extract_domain_from_title(app_name, window_title) if is_browser else None
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO app_usage 
                (start_time, end_time, app_name, window_title, duration_seconds, website_domain, is_browser)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (start_time, end_time, app_name, window_title, duration, domain, is_browser))
            
            # Update daily stats for app
            date_str = start_time.strftime('%Y-%m-%d')
            cursor.execute('''
                INSERT INTO daily_app_stats (date, app_name, total_seconds, session_count)
                VALUES (?, ?, ?, 1)
                ON CONFLICT(date, app_name) DO UPDATE SET
                    total_seconds = total_seconds + ?,
                    session_count = session_count + 1
            ''', (date_str, app_name, duration, duration))
            
            # Update daily stats for website if applicable
            if domain:
                cursor.execute('''
                    INSERT INTO daily_website_stats (date, domain, total_seconds, visit_count)
                    VALUES (?, ?, ?, 1)
                    ON CONFLICT(date, domain) DO UPDATE SET
                        total_seconds = total_seconds + ?,
                        visit_count = visit_count + 1
                ''', (date_str, domain, duration, duration))
            
            conn.commit()
        except sqlite3.Error as e:
            print(f"Error saving session: {e}")
        finally:
            conn.close()
    
    def track_once(self):
        """Single tracking iteration - check current window and save if changed."""
        app_name, window_title = self.get_active_window()
        now = datetime.now()
        
        if app_name is None:
            return
        
        # Check if app/window changed
        window_changed = (app_name != self.current_app or window_title != self.current_window)
        
        if window_changed:
            # Save previous session
            if self.current_app and self.current_start:
                self.save_session(
                    self.current_app, 
                    self.current_window or '', 
                    self.current_start, 
                    now
                )
            
            # Start new session
            self.current_app = app_name
            self.current_window = window_title
            self.current_start = now
    
    def run_daemon(self, interval: int = 5):
        """Run continuous tracking daemon."""
        self.poll_interval = interval
        self._running = True
        print(f"Starting active window tracking (polling every {interval}s)...")
        print("Press Ctrl+C to stop")
        
        self.current_start = datetime.now()
        
        while self._running:
            try:
                self.track_once()
                time.sleep(interval)
            except KeyboardInterrupt:
                print("\nStopping tracker...")
                # Save final session
                if self.current_app and self.current_start:
                    self.save_session(
                        self.current_app,
                        self.current_window or '',
                        self.current_start,
                        datetime.now()
                    )
                self._running = False
                break
            except Exception as e:
                print(f"Tracking error: {e}")
                time.sleep(interval)
    
    def stop(self):
        """Stop the tracking daemon."""
        self._running = False
        # Save final session
        if self.current_app and self.current_start:
            self.save_session(
                self.current_app,
                self.current_window or '',
                self.current_start,
                datetime.now()
            )
    
    def get_app_usage(self, minutes: int = 180) -> dict:
        """Get app usage stats for the last N minutes."""
        end = datetime.now()
        start = end - timedelta(minutes=minutes)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get app usage
        cursor.execute('''
            SELECT app_name, SUM(duration_seconds) as total, COUNT(*) as sessions
            FROM app_usage
            WHERE start_time BETWEEN ? AND ?
            GROUP BY app_name
            ORDER BY total DESC
        ''', (start, end))
        app_usage = cursor.fetchall()
        
        # Get website usage (from browser sessions)
        cursor.execute('''
            SELECT website_domain, SUM(duration_seconds) as total, COUNT(*) as visits
            FROM app_usage
            WHERE start_time BETWEEN ? AND ?
            AND website_domain IS NOT NULL
            GROUP BY website_domain
            ORDER BY total DESC
        ''', (start, end))
        website_usage = cursor.fetchall()
        
        # Get total tracked time
        cursor.execute('''
            SELECT SUM(duration_seconds)
            FROM app_usage
            WHERE start_time BETWEEN ? AND ?
        ''', (start, end))
        total_time = cursor.fetchone()[0] or 0
        
        conn.close()
        
        return {
            'start_time': start.strftime('%Y-%m-%d %H:%M:%S'),
            'end_time': end.strftime('%Y-%m-%d %H:%M:%S'),
            'total_seconds': total_time,
            'app_usage': [(app, secs, count) for app, secs, count in app_usage],
            'website_usage': [(site, secs, count) for site, secs, count in website_usage]
        }


class ActivityWatchIntegration:
    """Integrate with ActivityWatch for window tracking."""
    
    AW_API = "http://localhost:5600/api"
    
    def __init__(self, tracker_db_path: str):
        self.tracker_db_path = os.path.expanduser(tracker_db_path)
        
    def is_available(self) -> bool:
        """Check if ActivityWatch is running."""
        if not HAS_REQUESTS:
            return False
        try:
            response = requests.get(f"{self.AW_API}/0/info", timeout=2)
            return response.status_code == 200
        except:
            return False
    
    def get_window_events(self, hours: int = 24) -> list:
        """Get window events from ActivityWatch."""
        return []  # Simplified for stable version
    
    def save_window_events(self, events: list):
        """Save window events to the tracker database."""
        pass  # Simplified for stable version


class ReportGenerator:
    """Generate reports from tracked activity with enhanced HTML formatting."""
    
    def __init__(self, db_path: str):
        self.db_path = os.path.expanduser(db_path)
    
    def daily_summary(self, date: Optional[datetime] = None) -> dict:
        """Generate a daily activity summary."""
        if date is None:
            date = datetime.now()
        
        start = date.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Browser stats
        cursor.execute('''
            SELECT browser, COUNT(*) as visits
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY browser
            ORDER BY visits DESC
        ''', (start, end))
        browser_stats = dict(cursor.fetchall())
        
        # Video watching stats
        cursor.execute('''
            SELECT video_platform, COUNT(*) as count
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            AND is_video = 1
            GROUP BY video_platform
            ORDER BY count DESC
        ''', (start, end))
        video_stats = dict(cursor.fetchall())
        
        # Top sites
        cursor.execute('''
            SELECT 
                SUBSTR(url, INSTR(url, '://') + 3, 
                    CASE 
                        WHEN INSTR(SUBSTR(url, INSTR(url, '://') + 3), '/') > 0 
                        THEN INSTR(SUBSTR(url, INSTR(url, '://') + 3), '/') - 1
                        ELSE LENGTH(SUBSTR(url, INSTR(url, '://') + 3))
                    END
                ) as domain,
                COUNT(*) as visits
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY domain
            ORDER BY visits DESC
            LIMIT 10
        ''', (start, end))
        top_sites = cursor.fetchall()
        
        # Video titles watched
        cursor.execute('''
            SELECT title, video_platform, timestamp
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            AND is_video = 1
            ORDER BY timestamp DESC
            LIMIT 20
        ''', (start, end))
        videos_watched = cursor.fetchall()
        
        conn.close()
        
        return {
            'date': start.strftime('%Y-%m-%d'),
            'browser_visits': browser_stats,
            'video_platforms': video_stats,
            'top_sites': top_sites,
            'videos_watched': videos_watched
        }
    
    def print_report(self, date: Optional[datetime] = None):
        """Print a formatted daily report."""
        summary = self.daily_summary(date)
        
        print("\n" + "=" * 60)
        print(f"ACTIVITY REPORT - {summary['date']}")
        print("=" * 60)
        
        print("\n📊 BROWSER USAGE:")
        for browser, visits in summary['browser_visits'].items():
            print(f"  {browser}: {visits} page visits")
        
        print("\n🎬 VIDEO WATCHING:")
        if summary['video_platforms']:
            for platform, count in summary['video_platforms'].items():
                print(f"  {platform}: {count} videos")
        else:
            print("  No videos tracked")
        
        print("\n🌐 TOP SITES:")
        for domain, visits in summary['top_sites']:
            print(f"  {domain}: {visits} visits")
        
        print("\n📺 VIDEOS WATCHED:")
        if summary['videos_watched']:
            for title, platform, ts in summary['videos_watched'][:10]:
                title_short = title[:50] + "..." if len(title) > 50 else title
                print(f"  [{platform}] {title_short}")
        else:
            print("  No videos tracked")
        
        print("\n" + "=" * 60)
    def recent_summary(self, minutes: int = 30) -> dict:
        """Generate activity summary for the last N minutes."""
        end = datetime.now()
        start = end - timedelta(minutes=minutes)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Browser stats
        cursor.execute('''
            SELECT browser, COUNT(*) as visits
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY browser
            ORDER BY visits DESC
        ''', (start, end))
        browser_stats = dict(cursor.fetchall())
        
        # Video watching stats
        cursor.execute('''
            SELECT video_platform, COUNT(*) as count
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            AND is_video = 1
            GROUP BY video_platform
            ORDER BY count DESC
        ''', (start, end))
        video_stats = dict(cursor.fetchall())
        
        # Top sites
        cursor.execute('''
            SELECT 
                SUBSTR(url, INSTR(url, '://') + 3, 
                    CASE 
                        WHEN INSTR(SUBSTR(url, INSTR(url, '://') + 3), '/') > 0 
                        THEN INSTR(SUBSTR(url, INSTR(url, '://') + 3), '/') - 1
                        ELSE LENGTH(SUBSTR(url, INSTR(url, '://') + 3))
                    END
                ) as domain,
                COUNT(*) as visits
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY domain
            ORDER BY visits DESC
            LIMIT 10
        ''', (start, end))
        top_sites = cursor.fetchall()
        
        # All entries for raw data
        cursor.execute('''
            SELECT timestamp, browser, url, title, visit_duration_seconds, is_video, video_platform
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp DESC
        ''', (start, end))
        raw_entries = cursor.fetchall()
        
        # Video titles watched
        cursor.execute('''
            SELECT title, video_platform, timestamp, url
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            AND is_video = 1
            ORDER BY timestamp DESC
        ''', (start, end))
        videos_watched = cursor.fetchall()
        
        conn.close()
        
        return {
            'start_time': start.strftime('%Y-%m-%d %H:%M:%S'),
            'end_time': end.strftime('%Y-%m-%d %H:%M:%S'),
            'minutes': minutes,
            'total_pages': sum(browser_stats.values()) if browser_stats else 0,
            'browser_visits': browser_stats,
            'video_platforms': video_stats,
            'top_sites': top_sites,
            'videos_watched': videos_watched,
            'raw_entries': raw_entries
        }
    
    def format_report_text(self, summary: dict) -> str:
        """Format summary as text report."""
        lines = []
        lines.append("=" * 60)
        lines.append(f"ACTIVITY REPORT")
        lines.append(f"Period: {summary['start_time']} to {summary['end_time']}")
        lines.append(f"Duration: Last {summary['minutes']} minutes")
        lines.append(f"Total Pages Visited: {summary['total_pages']}")
        lines.append("=" * 60)
        
        lines.append("\n📊 BROWSER USAGE:")
        if summary['browser_visits']:
            for browser, visits in summary['browser_visits'].items():
                lines.append(f"  {browser}: {visits} page visits")
        else:
            lines.append("  No browsing activity")
        
        lines.append("\n🎬 VIDEO WATCHING:")
        if summary['video_platforms']:
            for platform, count in summary['video_platforms'].items():
                lines.append(f"  {platform}: {count} videos")
        else:
            lines.append("  No videos tracked")
        
        lines.append("\n🌐 TOP SITES:")
        if summary['top_sites']:
            for domain, visits in summary['top_sites']:
                lines.append(f"  {domain}: {visits} visits")
        else:
            lines.append("  No sites visited")
        
        lines.append("\n📺 VIDEOS WATCHED:")
        if summary['videos_watched']:
            for title, platform, ts, url in summary['videos_watched'][:15]:
                title_short = title[:60] + "..." if len(title) > 60 else title
                lines.append(f"  [{platform}] {title_short}")
        else:
            lines.append("  No videos tracked")
        
        lines.append("\n" + "=" * 60)
        return "\n".join(lines)
    
    def format_report_html(self, summary: dict) -> str:
        """Format summary as enhanced HTML report with interactive charts and timeline."""
        start = datetime.strptime(summary['start_time'], '%Y-%m-%d %H:%M:%S')
        end = datetime.strptime(summary['end_time'], '%Y-%m-%d %H:%M:%S')
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get hourly activity
        cursor.execute('''
            SELECT strftime('%H', timestamp) as hour, COUNT(*) as visits
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY hour
            ORDER BY hour
        ''', (start, end))
        hourly_activity = {int(h): c for h, c in cursor.fetchall()}
        
        # Get browser distribution
        cursor.execute('''
            SELECT browser, COUNT(*) as count
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY browser
            ORDER BY count DESC
            LIMIT 10
        ''', (start, end))
        browser_dist = cursor.fetchall()
        
        # Get top domains
        cursor.execute('''
            SELECT
                SUBSTR(url, INSTR(url, '://') + 3,
                    CASE
                        WHEN INSTR(SUBSTR(url, INSTR(url, '://') + 3), '/') > 0
                        THEN INSTR(SUBSTR(url, INSTR(url, '://') + 3), '/') - 1
                        ELSE LENGTH(SUBSTR(url, INSTR(url, '://') + 3))
                    END
                ) as domain,
                COUNT(*) as visits
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY domain
            ORDER BY visits DESC
            LIMIT 10
        ''', (start, end))
        top_domains = cursor.fetchall()
        
        # Get timeline data
        cursor.execute('''
            SELECT timestamp, browser, url, title, is_video, video_platform
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp DESC
            LIMIT 100
        ''', (start, end))
        timeline_entries = cursor.fetchall()
        
        # Get all entries for platform and category analysis
        cursor.execute('''
            SELECT url, title, timestamp
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
        ''', (start, end))
        all_entries = cursor.fetchall()
        
        conn.close()
        
        # Calculate platform distribution
        platform_counts = {}
        for url, title, ts in all_entries:
            platform = BrowserHistoryTracker.detect_platform(url)
            platform_counts[platform] = platform_counts.get(platform, 0) + 1
        
        # Sort by count and take top 7, group rest as 'Other'
        sorted_platforms = sorted(platform_counts.items(), key=lambda x: x[1], reverse=True)
        platform_data = []
        platform_labels = []
        other_count = 0
        for i, (platform, count) in enumerate(sorted_platforms):
            if i < 7:
                platform_labels.append(platform)
                platform_data.append(count)
            else:
                other_count += count
        if other_count > 0:
            platform_labels.append('Other')
            platform_data.append(other_count)
        
        # Calculate content categories
        category_counts = {}
        for url, title, ts in all_entries:
            category = BrowserHistoryTracker.categorize_content(url, title)
            category_counts[category] = category_counts.get(category, 0) + 1
        
        # Sort categories by count
        sorted_categories = sorted(category_counts.items(), key=lambda x: x[1], reverse=True)
        category_labels = [c[0] for c in sorted_categories[:8]]
        category_data = [c[1] for c in sorted_categories[:8]]
        
        # Calculate time block activity
        time_blocks = {}
        for url, title, ts in all_entries:
            # Parse timestamp
            if isinstance(ts, str):
                try:
                    ts_obj = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S.%f')
                except ValueError:
                    try:
                        ts_obj = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
                    except ValueError:
                        continue
            else:
                ts_obj = ts
            
            # Create time block label (e.g., "6-7 PM")
            hour = ts_obj.hour
            next_hour = (hour + 1) % 24
            if hour < 12:
                block_label = f"{hour if hour > 0 else 12}-{next_hour if next_hour < 12 else 12} {'AM' if hour < 11 else 'PM'}"
            else:
                h12 = hour - 12 if hour > 12 else 12
                nh12 = next_hour - 12 if next_hour > 12 else (12 if next_hour == 12 else next_hour)
                block_label = f"{h12}-{nh12 if next_hour != 0 else 12} {'PM' if next_hour != 0 else 'AM'}"
            
            time_blocks[hour] = time_blocks.get(hour, 0) + 1
        
        # Create ordered time block data
        if time_blocks:
            min_hour = min(time_blocks.keys())
            max_hour = max(time_blocks.keys())
            time_block_labels = []
            time_block_data = []
            for h in range(min_hour, max_hour + 1):
                # Format hour label
                if h == 0:
                    label = "12-1 AM"
                elif h < 12:
                    label = f"{h}-{h+1} AM"
                elif h == 12:
                    label = "12-1 PM"
                else:
                    label = f"{h-12}-{h-11 if h < 23 else 12} PM"
                time_block_labels.append(label)
                time_block_data.append(time_blocks.get(h, 0))
        else:
            time_block_labels = []
            time_block_data = []
        
        # Find peak activity hour
        peak_hour = max(time_blocks.keys(), key=lambda x: time_blocks[x]) if time_blocks else None
        peak_count = time_blocks.get(peak_hour, 0) if peak_hour is not None else 0
        
        # Calculate estimated time spent per website/platform
        # Sort entries by timestamp to calculate time between visits
        entries_with_ts = []
        for url, title, ts in all_entries:
            if isinstance(ts, str):
                try:
                    ts_obj = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S.%f')
                except ValueError:
                    try:
                        ts_obj = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
                    except ValueError:
                        continue
            else:
                ts_obj = ts
            entries_with_ts.append((url, title, ts_obj))
        
        # Sort by timestamp (oldest first)
        entries_with_ts.sort(key=lambda x: x[2])
        
        # Calculate time spent on each domain
        # Time on a page = time until next page visit (capped at 5 minutes to avoid counting idle time)
        MAX_TIME_ON_PAGE = 300  # 5 minutes max per page
        domain_time_seconds = {}
        platform_time_seconds = {}
        
        for i, (url, title, ts_obj) in enumerate(entries_with_ts):
            # Extract domain
            try:
                if '://' in url:
                    domain = url.split('://')[1].split('/')[0]
                    if domain.startswith('www.'):
                        domain = domain[4:]
                else:
                    domain = url.split('/')[0]
            except:
                domain = 'unknown'
            
            # Get platform
            platform = BrowserHistoryTracker.detect_platform(url)
            
            # Calculate time spent (time until next visit, capped)
            if i < len(entries_with_ts) - 1:
                next_ts = entries_with_ts[i + 1][2]
                time_diff = (next_ts - ts_obj).total_seconds()
                time_spent = min(time_diff, MAX_TIME_ON_PAGE)
            else:
                # Last entry - assume average time
                time_spent = 30  # 30 seconds default for last page
            
            # Accumulate time
            domain_time_seconds[domain] = domain_time_seconds.get(domain, 0) + time_spent
            platform_time_seconds[platform] = platform_time_seconds.get(platform, 0) + time_spent
        
        # Sort by time and get top 10 domains
        sorted_domain_time = sorted(domain_time_seconds.items(), key=lambda x: x[1], reverse=True)[:10]
        domain_time_labels = [d[0] for d in sorted_domain_time]
        domain_time_data = [round(d[1] / 60, 1) for d in sorted_domain_time]  # Convert to minutes
        
        # Sort platforms by time
        sorted_platform_time = sorted(platform_time_seconds.items(), key=lambda x: x[1], reverse=True)
        platform_time_labels = [p[0] for p in sorted_platform_time[:8]]
        platform_time_data = [round(p[1] / 60, 1) for p in sorted_platform_time[:8]]  # Convert to minutes
        
        # Calculate total time
        total_time_minutes = sum(domain_time_seconds.values()) / 60
        total_time_str = f"{int(total_time_minutes // 60)}h {int(total_time_minutes % 60)}m" if total_time_minutes >= 60 else f"{int(total_time_minutes)}m"
        
        duration = end - start
        duration_str = str(duration).split('.')[0]
        
        # Build enhanced HTML report
        html_parts = []
        
        # Header
        html_parts.append(f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Report - {start.strftime('%Y-%m-%d')}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .header {{
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }}
        .header h1 {{ font-size: 2.5em; color: white; margin-bottom: 10px; }}
        .header .meta {{ color: #aaa; font-size: 1.1em; }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }}
        .stat-card {{
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
        }}
        .stat-card .value {{ font-size: 2.5em; font-weight: 700; color: white; }}
        .stat-card .label {{ color: #aaa; font-size: 0.95em; margin-top: 5px; }}
        .card {{
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
        }}
        .card h2 {{
            font-size: 1.5em;
            color: white;
            margin-bottom: 20px;
            text-align: center;
            border-bottom: 2px solid rgba(255,255,255,0.1);
            padding-bottom: 10px;
        }}
        .chart-container {{ position: relative; height: 300px; margin: 20px 0; }}
        .timeline {{ position: relative; padding: 20px 0; }}
        .timeline::before {{
            content: '';
            position: absolute;
            left: 20px;
            top: 0;
            bottom: 0;
            width: 3px;
            background: linear-gradient(to bottom, #667eea, #764ba2);
            border-radius: 3px;
        }}
        .timeline-item {{
            position: relative;
            padding-left: 60px;
            padding-bottom: 20px;
        }}
        .timeline-item::before {{
            content: '';
            position: absolute;
            left: 14px;
            top: 5px;
            width: 15px;
            height: 15px;
            background: white;
            border: 3px solid #667eea;
            border-radius: 50%;
        }}
        .timeline-item.video::before {{
            border-color: #FF0000;
            background: #FF0000;
        }}
        .timeline-time {{
            font-size: 0.85em;
            color: #888;
            margin-bottom: 5px;
            font-family: monospace;
        }}
        .timeline-content {{
            background: rgba(255,255,255,0.05);
            padding: 15px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.1);
        }}
        .timeline-title {{
            font-weight: 600;
            color: white;
            margin-bottom: 5px;
            word-break: break-word;
        }}
        .timeline-url {{
            font-size: 0.85em;
            color: #aaa;
            word-break: break-all;
            margin-bottom: 8px;
        }}
        .timeline-browser {{
            font-size: 0.75em;
            background: rgba(255,255,255,0.1);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
        }}
        .video-badge {{
            background: #FF0000;
            color: white;
            font-size: 0.7em;
            padding: 2px 8px;
            border-radius: 10px;
            margin-left: 8px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Activity Report</h1>
            <div class="meta">
                <strong>Period:</strong> {start.strftime('%B %d, %Y %H:%M')} — {end.strftime('%B %d, %Y %H:%M')}<br>
                <strong>Duration:</strong> {duration_str}
            </div>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="icon">🌐</div>
                <div class="value">{summary.get('total_pages', 0):,}</div>
                <div class="label">Pages Visited</div>
            </div>
            <div class="stat-card">
                <div class="icon">⏱️</div>
                <div class="value">{total_time_str}</div>
                <div class="label">Est. Screen Time</div>
            </div>
            <div class="stat-card">
                <div class="icon">🔍</div>
                <div class="value">{len(summary.get('top_sites', []))}</div>
                <div class="label">Unique Sites</div>
            </div>
            <div class="stat-card">
                <div class="icon">📺</div>
                <div class="value">{len(summary.get('videos_watched', []))}</div>
                <div class="label">Videos Watched</div>
            </div>
            <div class="stat-card">
                <div class="icon">💻</div>
                <div class="value">{len(summary.get('browser_visits', dict()))}</div>
                <div class="label">Browsers Used</div>
            </div>
        </div>

        <div class="card">
            <h2>⏰ Hourly Activity</h2>
            <div class="chart-container">
                <canvas id="hourlyChart"></canvas>
            </div>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; margin-bottom: 20px;">
            <div class="card">
                <h2>⏱️ Time Spent by Website (minutes)</h2>
                <div class="chart-container">
                    <canvas id="domainTimeChart"></canvas>
                </div>
            </div>
            <div class="card">
                <h2>⏱️ Time Spent by Platform (minutes)</h2>
                <div class="chart-container">
                    <canvas id="platformTimeChart"></canvas>
                </div>
            </div>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; margin-bottom: 20px;">
            <div class="card">
                <h2>🌐 Visits by Platform</h2>
                <div class="chart-container">
                    <canvas id="platformChart"></canvas>
                </div>
            </div>
            <div class="card">
                <h2>📂 Content Categories</h2>
                <div class="chart-container">
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>📈 Activity Over Time</h2>
            <div class="chart-container">
                <canvas id="timeBlockChart"></canvas>
            </div>
            <p style="text-align: center; color: #888; font-size: 0.85rem; margin-top: 10px;">{'⚡ Peak activity: ' + (f'{peak_hour}:00-{peak_hour+1}:00 ({peak_count} visits)' if peak_hour is not None else 'N/A')}</p>
        </div>
        
        <div class="card">
            <h2>📜 Complete Browsing Timeline</h2>
            <div class="timeline">''')
        
        # Add timeline entries
        if timeline_entries:
            for ts, browser, url, title, is_video, platform in timeline_entries:
                video_class = 'video' if is_video else ''
                video_badge = f'<span class="video-badge">{platform}</span>' if is_video and platform else ''
                title_display = (title[:100] + '...') if title and len(title) > 100 else (title or 'Untitled')
                url_display = (url[:80] + '...') if url and len(url) > 80 else (url or '')
                
                # Format timestamp
                if isinstance(ts, str):
                    try:
                        ts_obj = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S.%f')
                    except ValueError:
                        try:
                            ts_obj = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
                        except ValueError:
                            ts_obj = datetime.now()
                else:
                    ts_obj = ts
                
                time_display = ts_obj.strftime('%H:%M:%S')
                
                html_parts.append(f'''
                <div class="timeline-item {video_class}">
                    <div class="timeline-time">{time_display}</div>
                    <div class="timeline-content">
                        <div class="timeline-title">{title_display}</div>
                        <div class="timeline-url">{url_display}</div>
                        <span class="timeline-browser">{browser}</span>
                        {video_badge}
                    </div>
                </div>''')
        else:
            html_parts.append('<p style="color: #888; text-align: center; font-style: italic;">No browsing activity in this period</p>')
        
        # Footer and JavaScript
        html_parts.append(f'''
            </div>
        </div>
        
        <div class="card" style="text-align: center; color: #aaa;">
            <p>Generated on {datetime.now().strftime('%B %d, %Y at %H:%M:%S')}</p>
            <p style="font-size: 0.9em; margin-top: 5px;">Activity Tracker</p>
        </div>
    </div>
    
    <script>
        const hourlyData = {json.dumps(list(hourly_activity.values()))};
        const hourlyLabels = {json.dumps([f'{{h:02d}}:00' for h in range(24)])};
        
        // Platform data
        const platformLabels = {json.dumps(platform_labels)};
        const platformData = {json.dumps(platform_data)};
        
        // Category data
        const categoryLabels = {json.dumps(category_labels)};
        const categoryData = {json.dumps(category_data)};
        
        // Time block data
        const timeBlockLabels = {json.dumps(time_block_labels)};
        const timeBlockData = {json.dumps(time_block_data)};
        
        // Time spent data (in minutes)
        const domainTimeLabels = {json.dumps(domain_time_labels)};
        const domainTimeData = {json.dumps(domain_time_data)};
        const platformTimeLabels = {json.dumps(platform_time_labels)};
        const platformTimeData = {json.dumps(platform_time_data)};
        
        // Color palettes
        const platformColors = ['#FF0000', '#4285F4', '#00E59B', '#1CAAD9', '#10A37F', '#9146FF', '#FF6B6B', '#888888'];
        const categoryColors = ['#8B4513', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#10A37F', '#DDA0DD', '#FFD93D'];
        const timeColors = ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe', '#00f2fe', '#43e97b', '#38f9d7', '#fa709a', '#fee140'];
        
        // Hourly Activity Chart
        new Chart(document.getElementById('hourlyChart'), {{
            type: 'bar',
            data: {{
                labels: hourlyLabels,
                datasets: [{{
                    data: hourlyData,
                    backgroundColor: '#4dabf7',
                    borderRadius: 5
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{ legend: {{ display: false }} }},
                scales: {{
                    y: {{
                        beginAtZero: true,
                        ticks: {{ color: '#aaa' }},
                        grid: {{ color: 'rgba(255,255,255,0.1)' }}
                    }},
                    x: {{ 
                        ticks: {{ color: '#aaa' }},
                        grid: {{ display: false }}
                    }}
                }}
            }}
        }});
        
        // Platform Doughnut Chart
        new Chart(document.getElementById('platformChart'), {{
            type: 'doughnut',
            data: {{
                labels: platformLabels,
                datasets: [{{
                    data: platformData,
                    backgroundColor: platformColors.slice(0, platformLabels.length),
                    borderWidth: 0
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{
                        position: 'right',
                        labels: {{ color: '#ccc', padding: 15, font: {{ size: 11 }} }}
                    }}
                }}
            }}
        }});
        
        // Content Categories Horizontal Bar Chart
        new Chart(document.getElementById('categoryChart'), {{
            type: 'bar',
            data: {{
                labels: categoryLabels,
                datasets: [{{
                    label: 'Page Visits',
                    data: categoryData,
                    backgroundColor: categoryColors.slice(0, categoryLabels.length),
                    borderRadius: 5
                }}]
            }},
            options: {{
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{ display: false }}
                }},
                scales: {{
                    x: {{ 
                        ticks: {{ color: '#888' }}, 
                        grid: {{ color: 'rgba(255,255,255,0.1)' }}
                    }},
                    y: {{ 
                        ticks: {{ color: '#ccc' }}, 
                        grid: {{ display: false }}
                    }}
                }}
            }}
        }});
        
        // Activity Over Time Bar Chart
        new Chart(document.getElementById('timeBlockChart'), {{
            type: 'bar',
            data: {{
                labels: timeBlockLabels,
                datasets: [{{
                    label: 'Page Visits',
                    data: timeBlockData,
                    backgroundColor: '#FF6B6B',
                    borderRadius: 5
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{ display: false }}
                }},
                scales: {{
                    x: {{ 
                        ticks: {{ color: '#888' }}, 
                        grid: {{ display: false }}
                    }},
                    y: {{ 
                        beginAtZero: true,
                        ticks: {{ color: '#888' }}, 
                        grid: {{ color: 'rgba(255,255,255,0.1)' }}
                    }}
                }}
            }}
        }});
        
        // Time Spent by Website (Horizontal Bar)
        new Chart(document.getElementById('domainTimeChart'), {{
            type: 'bar',
            data: {{
                labels: domainTimeLabels,
                datasets: [{{
                    label: 'Minutes',
                    data: domainTimeData,
                    backgroundColor: timeColors.slice(0, domainTimeLabels.length),
                    borderRadius: 5
                }}]
            }},
            options: {{
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{ display: false }},
                    tooltip: {{
                        callbacks: {{
                            label: function(context) {{
                                const mins = context.raw;
                                if (mins >= 60) {{
                                    return Math.floor(mins / 60) + 'h ' + Math.round(mins % 60) + 'm';
                                }}
                                return mins + ' min';
                            }}
                        }}
                    }}
                }},
                scales: {{
                    x: {{ 
                        ticks: {{ color: '#888' }}, 
                        grid: {{ color: 'rgba(255,255,255,0.1)' }},
                        title: {{ display: true, text: 'Minutes', color: '#888' }}
                    }},
                    y: {{ 
                        ticks: {{ color: '#ccc' }}, 
                        grid: {{ display: false }}
                    }}
                }}
            }}
        }});
        
        // Time Spent by Platform (Horizontal Bar)
        new Chart(document.getElementById('platformTimeChart'), {{
            type: 'bar',
            data: {{
                labels: platformTimeLabels,
                datasets: [{{
                    label: 'Minutes',
                    data: platformTimeData,
                    backgroundColor: platformColors.slice(0, platformTimeLabels.length),
                    borderRadius: 5
                }}]
            }},
            options: {{
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{ display: false }},
                    tooltip: {{
                        callbacks: {{
                            label: function(context) {{
                                const mins = context.raw;
                                if (mins >= 60) {{
                                    return Math.floor(mins / 60) + 'h ' + Math.round(mins % 60) + 'm';
                                }}
                                return mins + ' min';
                            }}
                        }}
                    }}
                }},
                scales: {{
                    x: {{ 
                        ticks: {{ color: '#888' }}, 
                        grid: {{ color: 'rgba(255,255,255,0.1)' }},
                        title: {{ display: true, text: 'Minutes', color: '#888' }}
                    }},
                    y: {{ 
                        ticks: {{ color: '#ccc' }}, 
                        grid: {{ display: false }}
                    }}
                }}
            }}
        }});
    </script>
</body>
</html>''')
        
        return ''.join(html_parts)
    
    def calculate_time_spent(self, summary: dict) -> dict:
        """Calculate time spent per website, platform, and app from tracked data."""
        start = datetime.strptime(summary['start_time'], '%Y-%m-%d %H:%M:%S')
        end = datetime.strptime(summary['end_time'], '%Y-%m-%d %H:%M:%S')
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # First try to get ACTUAL tracked time from app_usage table
        cursor.execute('''
            SELECT app_name, SUM(duration_seconds), COUNT(*)
            FROM app_usage
            WHERE start_time BETWEEN ? AND ?
            GROUP BY app_name
            ORDER BY SUM(duration_seconds) DESC
        ''', (start, end))
        actual_app_usage = cursor.fetchall()
        
        cursor.execute('''
            SELECT website_domain, SUM(duration_seconds), COUNT(*)
            FROM app_usage
            WHERE start_time BETWEEN ? AND ?
            AND website_domain IS NOT NULL
            GROUP BY website_domain
            ORDER BY SUM(duration_seconds) DESC
        ''', (start, end))
        actual_website_usage = cursor.fetchall()
        
        cursor.execute('''
            SELECT SUM(duration_seconds)
            FROM app_usage
            WHERE start_time BETWEEN ? AND ?
        ''', (start, end))
        actual_total = cursor.fetchone()[0] or 0
        
        # Also get estimated time from browser history for comparison/fallback
        cursor.execute('''
            SELECT url, title, timestamp
            FROM browser_history
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp ASC
        ''', (start, end))
        all_entries = cursor.fetchall()
        conn.close()
        
        # Parse timestamps and calculate estimated time
        entries_with_ts = []
        for url, title, ts in all_entries:
            if isinstance(ts, str):
                try:
                    ts_obj = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S.%f')
                except ValueError:
                    try:
                        ts_obj = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
                    except ValueError:
                        continue
            else:
                ts_obj = ts
            entries_with_ts.append((url, title, ts_obj))
        
        entries_with_ts.sort(key=lambda x: x[2])
        
        # Calculate estimated time per domain and platform from browser history
        MAX_TIME_ON_PAGE = 300
        domain_time = {}
        platform_time = {}
        domain_visits = {}
        platform_visits = {}
        
        for i, (url, title, ts_obj) in enumerate(entries_with_ts):
            try:
                if '://' in url:
                    domain = url.split('://')[1].split('/')[0]
                    if domain.startswith('www.'):
                        domain = domain[4:]
                else:
                    domain = url.split('/')[0]
            except:
                domain = 'unknown'
            
            platform = BrowserHistoryTracker.detect_platform(url)
            domain_visits[domain] = domain_visits.get(domain, 0) + 1
            platform_visits[platform] = platform_visits.get(platform, 0) + 1
            
            if i < len(entries_with_ts) - 1:
                next_ts = entries_with_ts[i + 1][2]
                time_diff = (next_ts - ts_obj).total_seconds()
                time_spent = min(time_diff, MAX_TIME_ON_PAGE)
            else:
                time_spent = 30
            
            domain_time[domain] = domain_time.get(domain, 0) + time_spent
            platform_time[platform] = platform_time.get(platform, 0) + time_spent
        
        sorted_domains = sorted(domain_time.items(), key=lambda x: x[1], reverse=True)
        sorted_platforms = sorted(platform_time.items(), key=lambda x: x[1], reverse=True)
        
        # Use actual tracked data if available, otherwise use estimated
        has_actual_data = actual_total > 0
        
        result = {
            'has_actual_tracking': has_actual_data,
            'domain_visits': domain_visits,
            'platform_visits': platform_visits,
        }
        
        if has_actual_data:
            # Use actual tracked time
            result['total_minutes'] = actual_total / 60
            result['by_domain'] = [(d, t/60) for d, t, c in actual_website_usage]
            result['by_app'] = [(a, t/60, c) for a, t, c in actual_app_usage]
            result['website_visits'] = {d: c for d, t, c in actual_website_usage}
            result['app_sessions'] = {a: c for a, t, c in actual_app_usage}
            # Also include platform estimate for charts
            result['by_platform'] = [(p, t/60) for p, t in sorted_platforms]
        else:
            # Use estimated time from browser history
            result['total_minutes'] = sum(domain_time.values()) / 60
            result['by_domain'] = [(d, t/60) for d, t in sorted_domains]
            result['by_platform'] = [(p, t/60) for p, t in sorted_platforms]
            result['by_app'] = []
            result['website_visits'] = domain_visits
            result['app_sessions'] = {}
        
        return result
    
    def export_csv(self, filename: str, days: int = 7):
        """Export activity data to CSV file."""
        print(f"CSV export not yet implemented for {filename}")


class EmailReporter:
    """Send activity reports via email."""
    
    def __init__(self, config_path: str = "~/.local/.metadata_sync.json"):
        self.config_path = os.path.expanduser(config_path)
        self.config = self._load_config()
    
    def _load_config(self) -> dict:
        """Load email configuration from file."""
        if os.path.exists(self.config_path):
            with open(self.config_path, 'r') as f:
                return json.load(f)
        return {}
    
    def is_configured(self) -> bool:
        """Check if email is properly configured."""
        required = ['smtp_server', 'smtp_port', 'sender_email', 'sender_password', 'recipient_email']
        return all(key in self.config for key in required)
    
    def send_report(self, summary: dict, reporter) -> bool:
        """Send activity report via email with HTML attachment."""
        if not self.is_configured():
            print("Email not configured.")
            return False
        
        try:
            # Create message with mixed content (for attachments)
            msg = MIMEMultipart('mixed')
            msg['Subject'] = f"📊 Screen Time Report - {summary['start_time'][:10]}"
            msg['From'] = self.config['sender_email']
            msg['To'] = self.config['recipient_email']
            
            # Calculate time spent per site for email body
            time_spent_data = reporter.calculate_time_spent(summary)
            
            # Create simple email body with time spent summary
            text_body = self._format_email_body(summary, time_spent_data)
            html_body = self._format_email_body_html(summary, time_spent_data)
            
            # Create alternative part for text and HTML body
            msg_alternative = MIMEMultipart('alternative')
            msg.attach(msg_alternative)
            
            # Plain text version
            msg_alternative.attach(MIMEText(text_body, 'plain'))
            
            # HTML version (inline body)
            msg_alternative.attach(MIMEText(html_body, 'html'))
            
            # Attach full HTML report as downloadable attachment
            html_content = reporter.format_report_html(summary)
            attachment = MIMEText(html_content, 'html', 'utf-8')
            attachment.add_header('Content-Disposition', 'attachment',
                                filename=f'report_{summary["start_time"][:10].replace("-", "")}.html')
            msg.attach(attachment)
            
            # Send email
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            if self.config.get('use_tls', True):
                with smtplib.SMTP(self.config['smtp_server'], self.config['smtp_port']) as server:
                    server.starttls(context=context)
                    server.login(self.config['sender_email'], self.config['sender_password'])
                    server.sendmail(self.config['sender_email'], self.config['recipient_email'], msg.as_string())
            else:
                with smtplib.SMTP_SSL(self.config['smtp_server'], self.config['smtp_port'], context=context) as server:
                    server.login(self.config['sender_email'], self.config['sender_password'])
                    server.sendmail(self.config['sender_email'], self.config['recipient_email'], msg.as_string())
            
            print(f"✅ Report sent to {self.config['recipient_email']}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to send email: {e}")
            return False
    
    def _format_email_body(self, summary: dict, time_data: dict) -> str:
        """Format simple text email body with time spent summary."""
        lines = []
        lines.append(f"Screen Time Report")
        lines.append(f"Period: {summary['start_time']} to {summary['end_time']}")
        lines.append(f"")
        lines.append(f"{'─' * 50}")
        lines.append(f"")
        
        # Total stats
        total_mins = time_data.get('total_minutes', 0)
        if total_mins >= 60:
            total_str = f"{int(total_mins // 60)}h {int(total_mins % 60)}m"
        else:
            total_str = f"{int(total_mins)}m"
        
        tracking_type = "Actual" if time_data.get('has_actual_tracking') else "Estimated"
        lines.append(f"📱 Total Screen Time: {total_str} ({tracking_type})")
        lines.append(f"🌐 Total Pages: {summary.get('total_pages', 0)}")
        lines.append(f"")
        
        # App usage section (if available)
        if time_data.get('by_app'):
            lines.append(f"{'─' * 50}")
            lines.append(f"⏱️ TIME BY APPLICATION (Actual)")
            lines.append(f"{'─' * 50}")
            lines.append(f"")
            
            for app, mins, *rest in time_data.get('by_app', [])[:12]:
                if mins >= 60:
                    time_str = f"{int(mins // 60)}h {int(mins % 60)}m"
                else:
                    time_str = f"{mins:.0f}m"
                sessions = time_data.get('app_sessions', {}).get(app, rest[0] if rest else 0)
                lines.append(f"  {app:<30} {time_str:>8}  ({sessions} sessions)")
            
            lines.append(f"")
        
        lines.append(f"{'─' * 50}")
        lines.append(f"🌐 TIME BY WEBSITE")
        lines.append(f"{'─' * 50}")
        lines.append(f"")
        
        # Time by website
        for site, mins in time_data.get('by_domain', [])[:12]:
            if mins >= 60:
                time_str = f"{int(mins // 60)}h {int(mins % 60)}m"
            else:
                time_str = f"{mins:.0f}m"
            visits = time_data.get('website_visits', time_data.get('domain_visits', {})).get(site, 0)
            lines.append(f"  {site:<30} {time_str:>8}  ({visits} visits)")
        
        lines.append(f"")
        lines.append(f"{'─' * 50}")
        lines.append(f"")
        lines.append(f"📎 Full report attached")
        
        return "\n".join(lines)
    
    def _format_email_body_html(self, summary: dict, time_data: dict) -> str:
        """Format HTML email body with time spent summary."""
        total_mins = time_data.get('total_minutes', 0)
        if total_mins >= 60:
            total_str = f"{int(total_mins // 60)}h {int(total_mins % 60)}m"
        else:
            total_str = f"{int(total_mins)}m"
        
        tracking_badge = "✓ Actual" if time_data.get('has_actual_tracking') else "~ Estimated"
        num_apps = len(time_data.get('by_app', []))
        
        html = f'''<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; padding: 20px; }}
        .container {{ max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; text-align: center; }}
        .header h1 {{ margin: 0; font-size: 24px; }}
        .header p {{ margin: 10px 0 0 0; opacity: 0.9; font-size: 14px; }}
        .badge {{ display: inline-block; background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 20px; font-size: 11px; margin-top: 8px; }}
        .stats {{ display: flex; justify-content: space-around; padding: 20px; background: #fafafa; border-bottom: 1px solid #eee; }}
        .stat {{ text-align: center; }}
        .stat-value {{ font-size: 28px; font-weight: bold; color: #333; }}
        .stat-label {{ font-size: 12px; color: #888; margin-top: 5px; }}
        .section {{ padding: 20px; border-bottom: 1px solid #f0f0f0; }}
        .section:last-of-type {{ border-bottom: none; }}
        .section-title {{ font-size: 14px; font-weight: 600; color: #888; margin-bottom: 15px; text-transform: uppercase; letter-spacing: 1px; }}
        .site-row {{ display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f0f0f0; }}
        .site-row:last-child {{ border-bottom: none; }}
        .site-name {{ color: #333; font-weight: 500; max-width: 200px; overflow: hidden; text-overflow: ellipsis; }}
        .site-stats {{ text-align: right; }}
        .site-time {{ color: #667eea; font-weight: 600; }}
        .site-visits {{ color: #888; font-size: 12px; }}
        .footer {{ padding: 15px; text-align: center; color: #888; font-size: 12px; background: #fafafa; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Screen Time Report</h1>
            <p>{summary['start_time'][:16]} to {summary['end_time'][11:16]}</p>
            <span class="badge">{tracking_badge}</span>
        </div>
        
        <div class="stats">
            <div class="stat">
                <div class="stat-value">{total_str}</div>
                <div class="stat-label">Screen Time</div>
            </div>
            <div class="stat">
                <div class="stat-value">{num_apps if num_apps > 0 else summary.get('total_pages', 0)}</div>
                <div class="stat-label">{'Apps Used' if num_apps > 0 else 'Pages'}</div>
            </div>
            <div class="stat">
                <div class="stat-value">{len(time_data.get('by_domain', []))}</div>
                <div class="stat-label">Websites</div>
            </div>
        </div>
'''
        
        # Add App Usage section if available
        if time_data.get('by_app'):
            html += '''
        <div class="section">
            <div class="section-title">💻 Time by Application</div>
'''
            for app, mins, *rest in time_data.get('by_app', [])[:8]:
                if mins >= 60:
                    time_str = f"{int(mins // 60)}h {int(mins % 60)}m"
                else:
                    time_str = f"{mins:.0f}m"
                sessions = time_data.get('app_sessions', {}).get(app, rest[0] if rest else 0)
                html += f'''            <div class="site-row">
                <span class="site-name">{app}</span>
                <div class="site-stats">
                    <div class="site-time">{time_str}</div>
                    <div class="site-visits">{sessions} sessions</div>
                </div>
            </div>
'''
            html += '''        </div>
'''
        
        # Website section
        html += '''
        <div class="section">
            <div class="section-title">🌐 Time by Website</div>
'''
        
        for site, mins in time_data.get('by_domain', [])[:8]:
            if mins >= 60:
                time_str = f"{int(mins // 60)}h {int(mins % 60)}m"
            else:
                time_str = f"{mins:.0f}m"
            visits = time_data.get('website_visits', time_data.get('domain_visits', {})).get(site, 0)
            html += f'''            <div class="site-row">
                <span class="site-name">{site}</span>
                <div class="site-stats">
                    <div class="site-time">{time_str}</div>
                    <div class="site-visits">{visits} visits</div>
                </div>
            </div>
'''
        
        html += '''        </div>
        
        <div class="footer">
            📎 Full interactive report attached
        </div>
    </div>
</body>
</html>'''
        
        return html



def main():
    parser = argparse.ArgumentParser(description='Screen Time Tracker with App & Website Monitoring')
    
    # Basic operations
    parser.add_argument('--daemon', action='store_true', help='Run browser history collection continuously')
    parser.add_argument('--interval', type=int, default=300, help='Polling interval in seconds (default: 300)')
    parser.add_argument('--report', action='store_true', help='Generate daily report')
    parser.add_argument('--export', type=str, help='Export to CSV file')
    parser.add_argument('--days', type=int, default=7, help='Days to export (default: 7)')
    parser.add_argument('--db', type=str, default='~/.local/share/.cache_index.db', help='Database path')
    
    # Active tracking mode (real-time app/window monitoring)
    parser.add_argument('--track', action='store_true', help='Run real-time active window tracking')
    parser.add_argument('--track-interval', type=int, default=5, help='Tracking poll interval in seconds (default: 5)')
    
    # Scheduled/email operations
    parser.add_argument('--scheduled', action='store_true', help='Run scheduled collection with report')
    parser.add_argument('--minutes', type=int, default=30, help='Minutes of history to report (default: 30)')
    parser.add_argument('--send-email', action='store_true', help='Send report via email')
    parser.add_argument('--html', type=str, help='Save HTML report to file')
    
    args = parser.parse_args()
    
    # Ensure directories exist
    db_path = os.path.expanduser(args.db)
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    tracker = BrowserHistoryTracker(args.db)
    active_tracker = ActiveWindowTracker(args.db)
    aw_integration = ActivityWatchIntegration(args.db)
    reporter = ReportGenerator(args.db)
    email_reporter = EmailReporter()
    
    if args.report:
        reporter.print_report()
        return
    
    if args.export:
        reporter.export_csv(args.export, args.days)
        return
    
    # Real-time active window tracking mode
    if args.track:
        print(f"Starting real-time screen tracking...")
        print(f"Polling every {args.track_interval} seconds")
        print("This tracks actual time spent in each app/website")
        print("Press Ctrl+C to stop\n")
        active_tracker.run_daemon(interval=args.track_interval)
        return
    
    # Scheduled run with optional email
    if args.scheduled:
        print(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Scheduled collection...")
        
        # Collect browser history
        entries = tracker.collect_all_history()
        tracker.save_entries(entries)
        
        # Collect ActivityWatch data if available
        if aw_integration.is_available():
            window_events = aw_integration.get_window_events(hours=1)
            aw_integration.save_window_events(window_events)
        
        # Generate report for last N minutes
        summary = reporter.recent_summary(args.minutes)
        
        # Print report
        print(reporter.format_report_text(summary))
        
        # Send email if requested
        if args.send_email:
            email_reporter.send_report(summary, reporter)
        
        # Save HTML report if requested
        if args.html:
            os.makedirs(os.path.dirname(os.path.expanduser(args.html)), exist_ok=True)
            html_content = reporter.format_report_html(summary)
            with open(os.path.expanduser(args.html), 'w', encoding='utf-8') as f:
                f.write(html_content)
            print(f"✅ HTML report saved to: {args.html}")
        
        return
    
    def run_once():
        print(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Collecting activity...")
        
        # Collect browser history
        entries = tracker.collect_all_history()
        tracker.save_entries(entries)
        
        # Collect ActivityWatch data if available
        if aw_integration.is_available():
            print("Syncing with ActivityWatch...")
            window_events = aw_integration.get_window_events(hours=24)
            aw_integration.save_window_events(window_events)
            print(f"  Synced {len(window_events)} window events")
    
    if args.daemon:
        print(f"Starting daemon mode (polling every {args.interval} seconds)")
        print("Press Ctrl+C to stop")
        while True:
            try:
                run_once()
                time.sleep(args.interval)
            except KeyboardInterrupt:
                print("\nStopping...")
                break
    else:
        run_once()
        print(f"\nDatabase saved to: {tracker.db_path}")
        print("\nUsage modes:")
        print("  --track          Real-time app/website tracking (recommended)")
        print("  --daemon         Browser history collection")
        print("  --report         View daily summary")
        print("  --scheduled      Collect + email report")


if __name__ == "__main__":
    main()
